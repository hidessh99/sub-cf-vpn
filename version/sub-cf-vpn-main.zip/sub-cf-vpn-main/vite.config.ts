import path from 'path';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [
    react()
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    proxy: {
      '/api/v1': {
        target: 'http://localhost:4002',
        changeOrigin: true,
      },
      '/api/check': {
        target: 'http://localhost:4002',
        changeOrigin: true,
      },
    },
  },
})
